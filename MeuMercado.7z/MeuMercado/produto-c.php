<html>
<head>
	<title>Consulta de Produtos</title>
	<link rel="stylesheet" href="css/estilo.css" type="text/css"></link>
	<link rel="shortcut icon" href="imagens/elderly.ico">
</head>
<body>
<?php

error_reporting(0);

	include_once("./classes/Conexao.class.php");
	include_once("./classes/Produtos.class.php");

	$conn           = new Conexao();
	$produto        = new Produtos($codigoProduto,$nomeProduto,$tipoProduto,$valorProduto,$estoqueProduto);
	
	$produto->listarProduto();


	?>
</body>
</html>