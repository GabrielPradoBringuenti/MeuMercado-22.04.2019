<?php
	class Conexao{
		
		protected $id;
		protected $conn;
			
		
		function __construct(){
		
			$local 		= "localhost";
			$dbname	 	= "MeuMercado";
			$usuario	= "root";
			$password	= "";
			
			if(!($this->id = mysql_connect($local,$usuario,$password))){
				echo"Não foi possivel realizar uma conexão com o Servidor.";
				exit;
			}
			
			if(!($this->conn = mysql_select_db($dbname,$this->id))){
				echo"Não foi possivel realizar uma conexão com o Banco de Dados.";
				exit;
			}
			
		}
		
		function __destruct(){
		
			mysql_close($this->id);
		}
	}
?>