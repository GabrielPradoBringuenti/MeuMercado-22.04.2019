<?php

	class  Produtos{
		
		private $codigoProduto;
		private $nomeProduto;
        private $tipoProduto;
		private $valorProduto;
		private $estoqueProduto;
		
		
		public function __construct($codigoProduto,$nomeProduto,$tipoProduto,$valorProduto,$estoqueProduto){
			
			$this->codigoProduto               	    = $codigoProduto;
			$this->nomeProduto               	    = $nomeProduto;
			$this->tipoProduto                 	    = $tipoProduto;
			$this->valorProduto       	            = $valorProduto;
			$this->estoqueProduto                   = $estoqueProduto;		
		}
		
		//GETERS
		
		public function getCodigoProduto(){
			
			
			return	 $this->codigoProduto;
		
		
		}
		
		public function getNomeProduto(){
			
			
			return	 $this->nomeProduto;
		
		
		}
		
		public function getTipoProduto(){
		
			
			return	 $this->tipoProduto;
		
		}
		public function getValorProduto(){
		
			
			return	 $this->valorProduto;
		
		}
		
		public function getEstoqueProduto(){
		
			
			return $this->estoqueProduto;
		
		}
		
		
		//SETTERS
		public function setCodigoProduto($codigoProduto){
	
			$this->codigoProduto = $codigoProduto;
		}
		
		public function setNomeProduto($nomeProduto){
		
			$this->nomeProduto = $nomeProduto;
			
		}
		
		public function setTipoProduto($tipoProduto){
		
			$this->tipoProduto = $tipoProduto;
			
		}
		
		public function setValorProduto($valorProduto){
		
			$this->valorProduto = $valorProduto;
			
		}
		
		public function setEstoqueProduto($estoqueProduto){
		
			$this->estoqueProduto = $estoqueProduto;
			
		}
		
		
		//Metodo de Inclusão
			public function IncluirProduto(){
		if(!$this->localizarProduto($this->getCodigoProduto())){
			$query = "INSERT INTO produtos(
										
											codigoProduto,
											nomeProduto,
											tipoProduto,
										    valorProduto,
										    estoqueProduto
										    
											) VALUES(	'" .$this->getCodigoProduto() 			 	      . "',
															'" .$this->getNomeProduto() 			 . "',
														    '" .$this->getTipoProduto()   			 	 . "',
															'" .$this->getValorProduto()   	 . "',
															'" .$this->getEstoqueProduto()    			 	 . "');";		
															
		//echo $query;
			return mysql_query($query) or die(mysql_error());
	}else{
		return false;
	}
}
		
   public function alterarProduto($codigoProduto) {
		// altera o valor dos atributos da area no banco atraves de sql embutido
		$query = "UPDATE produtos
					SET	codigoProduto               = '" .$this->getCodigoProduto()."',
						nomeProduto 	            = '" . $this->getNomeProduto(). "',
					    tipoProduto   	            = '" . $this->getTipoProduto(). "',
						valorProduto 	            = '" . $this->getValorProduto(). "',
						estoqueProduto 	            = '" . $this->getEstoqueProduto(). "'
						WHERE codigoProduto 	    = '" . $codigoProduto."';";
        //echo $query;				  

		return mysql_query($query)or die(mysql_error());
    }
		
//Método de Exclusão
	//Método de Exclusão
	public function excluirProduto($codigoProduto){
		//Exclui um cadastro no banco
			$query = "	DELETE
						FROM produtos
						WHERE codigoProduto = '" . $codigoProduto . "'; ";
		
		//echo $query;
		return mysql_query($query);
	}
	
	
    public function listarProduto(){
	//lista todos os produtos do banco de dados
	
		$query = " SELECT p.codigoProduto,
						  p.nomeProduto,
						  p.tipoProduto,
						  p.valorProduto,
						  p.estoqueProduto
					FROM  produtos p
					ORDER BY p.nomeProduto"; 
				
			$res = mysql_query($query)or die(mysql_error());
			$nr  = (int)mysql_num_rows($res);
			
			//Tabela com os valores retornados do  result set
			
			echo"<table align=\"center\" border=\"1\">";
				echo"<tr>";
					echo"<tr><th align=\"center\">Produtos</th></tr>";
					echo"<tr>";
						echo"<th>Codigo Produto</th><th>Produto</th><th>Tipo Produto</th><th>Valor Produto</th><th>Estoque</th><th>Alterar</th><th>Excluir</th>";
					echo"</tr>";
					
					if($nr == 0){
					echo"<tr><td>Sem registros de produtos para consulta</td></tr>";
					/*echo"<td align=\"center\">";
						echo"<a href=\"index.php?pag=logradouro-f.php\"><img src=\"./imagens/circle-arrow-left-32.png\" title=\"Voltar para a p&aacute;gina de logradouro\"/></a>";
					echo"</td>";*/
						
						
					
					}else{
						while($array = mysql_fetch_array($res)){
							echo"<tr>";
								// parte dinâmica do código, onde é inserido os valores individuais de cada registro, através do nome do atributo na tabela.
								echo"<td align=\"center\">" 				.	$array['codigoProduto']					."</td>";
								echo"<td><b>"								.	$array['nomeProduto']						."</b></td>";
								echo"<td><b>"								.	$array['tipoProduto']						."</b></td>";
								echo"<td><b>"								.	$array['valorProduto']						."</b></td>";
								echo"<td><b>"								.	$array['estoqueProduto']						."</b></td>";
								
								echo"<td><a href=cadastroProduto-p.php?acao=1&chave="	. $array['codigoProduto'] . "><img src=\"./imagens/alterar.jpg\"  		title=\"Alterar Produto\"></a></td>";
								
								echo"<td><a href=cadastroProduto-p.php?acao=2&chave="	. $array['codigoProduto'] . "><img src=\"./imagens/lixeira.png\"	title=\"Excluir Produto\"></a></td>";
								
							echo"</tr>";
						}	
				}
					
				echo "<tr>";
			    echo    "<td><a href=\"cadastroProduto-f.php\" title=\"voltar\"><img name=\"botaoVoltar\" src=\"./imagens/circle-arrow-left-32.png\"/></a><a href=\"produto-c.php\" title=\"atualizar\"><img name=\"botaoAtualizar\" src=\"./imagens/update.png\"/></a></td>";
				echo "</tr>";
				echo"</tr>";
				echo"</table>";
	}			
	
	    public function localizarProduto($codigoProduto){
		if(isset($codigoProduto)){
			$query = "SELECT 		p.codigoProduto,
			                        p.nomeProduto,
									p.tipoProduto,
									p.valorProduto,
									p.estoqueProduto
						FROM 		produtos p
						WHERE		p.codigoProduto = '" . $codigoProduto ."';";
			//echo $query;
			
			if($res = mysql_query($query)){
				$row 	=  mysql_fetch_row($res);
				$nr 	= (int) mysql_num_rows($res);
				
				if($nr === 1){
					// localizou o registro coloca os valores encontrados no banco no objeto atual
	
					$this->setCodigoProduto($row[0]);
					$this->setNomeProduto($row[1]);
					$this->setTipoProduto($row[2]);
					$this->setValorProduto($row[3]);
					$this->setEstoqueProduto($row[4]);
					
					
					
					return (true);
				}else{
					return (false);
				}		
			}else{
				return (false);
			}
		}
	}	
}



?>