<?php

	$codigoProduto  = $_POST["codigoProduto"];
	$nomeProduto    = $_POST["nomeProduto"];
	$tipoProduto    = $_POST["tipoProduto"];
	$valorProduto   = $_POST["valorProduto"];
	$estoqueProduto = $_POST["estoqueProduto"];
	
	
	if(isset($_GET['acao'])){
		$acao = $_GET['acao'];
	}
	
	if(isset($_GET['chave'])){
		$chave= $_GET['chave'];
	}
	
	include_once("./classes/Conexao.class.php");
	include_once("./classes/Produtos.class.php");
	
	$conn		  = new Conexao();
	$produto      = new Produtos($codigoProduto,$nomeProduto,$tipoProduto,$valorProduto,$estoqueProduto);
	
	switch($acao){
		case 0: //Inclusão - vem do formulário
			if($produto->IncluirProduto()){
				$mensagem = "Produto cadastrado com sucesso !";
			}else{
				$mensagem = "O Produto já foi cadastrado. Verifique !";
			}
			
			
			echo "<script language=\"javascript\" type=\"text/javascript\">";
			echo	"alert(\"$mensagem\");";
			echo	"location.href='produto-c.php';";
			echo "</script>";
			break;
		
		case 1: //	formulario de alteracao de dados - vem do listar da classe
			echo "<script language=\"javascript\" type=\"text/javascript\">";
			echo  "location.href='produto-a.php?chave=$chave';";
			echo "</script>";
			break;
		
		case 2: //exclusão - vem do listar da classe
			if($produto->excluirProduto($chave)){
				$mensagem = "O registro foi excluído !";
			}else{
				$mensagem = "O registro não foi excluido. Verifique !";
			}
			
			echo "<script language=\"javascript\" type=\"text/javascript\">";
			echo	"alert(\"$mensagem\");";
			echo	"location.href='produto-c.php?pag=produto-c.php';";
			echo "</script>";
			break;
			
		case 3: // altera - ve do formulário do alteração -a
			if($produto->alterarProduto($chave)){
				$mensagem = "O Produto foi alterado com sucesso !";
			} else {
				$mensagem = "O Produto não foi alterado. Verifique !";
			}
			
			echo "<script language=\"javascript\" type=\"text/javascript\">";
			echo	"alert(\"$mensagem\");";
			echo	"location.href='produto-c.php';";
			echo "</script>";
			break;
	}
	


	
	
	
	
	

?>