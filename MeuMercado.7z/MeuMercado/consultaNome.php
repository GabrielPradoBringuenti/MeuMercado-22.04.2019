<html>
<body>
		<form name="frmBusca" method="post" action="<?php echo $_SERVER['PHP_SELF'] ?>?a=buscar" >
			<table align="center">
			<td><label>Produto</label></td>
				<td><input type="text" placeholder="Buscar Produto"></td>
				<td><input type="submit"  value="Buscar" /></td>
				</tr>
			</table>
		</form>
	</body>
</html>



<?php



error_reporting(0);


	include_once("./classes/Conexao.class.php");
	include_once("./classes/Produtos.class.php");
	
$conn		  = new Conexao();
$produto      = new Produtos($codigoProduto,$nomeProduto,$tipoProduto,$valorProduto,$estoqueProduto);





// Recuperamos a ação enviada pelo formulário
$a = $_GET['a'];
 
// Verificamos se a ação é de busca
if ($a == "buscar") {
 
	// Pegamos a palavra
	$palavra = trim($_POST['palavra']);
 
	// Verificamos no banco de dados produtos equivalente a palavra digitada
	$sql = mysql_query("SELECT * FROM produtos WHERE nomeProduto LIKE '%".$palavra."%' ORDER BY nomeProduto");
 
	// Descobrimos o total de registros encontrados
	$numRegistros = mysql_num_rows($sql);
 
	// Se houver pelo menos um registro, exibe-o
	if ($numRegistros != 0) {
		// Exibe os produtos e seus respectivos preços
		while ($produto = mysql_fetch_object($sql)) {
			echo $produto->nomeProduto . " <br />";
		}
	// Se não houver registros
	} else {
		echo "Nenhum produto foi encontrado com a palavra ".$palavra."";
	}
}



?>