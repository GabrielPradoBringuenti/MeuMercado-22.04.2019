<html>
	<head>
		<title>Login</title>
		<link rel="stylesheet" type="text/css" href="css/estilo.css">
		<link rel="shortcut icon" href="imagens/elderly.ico">
		<link href="http://fonts.googleapis.com/css?family=Oswald:400,300,700" rel="stylesheet" type="text/css"/>	
	</head>
	<body>
		   <form name="formLogin"  action="logar.php" method="POST">
			<div id="cadastrar"><a href="bairro-f.php"  title="Cadastre-se e faca parte do Portal de busca de cuidadores">Cadastre-se &raquo;</a></div>


<div class="fb-login-button" data-max-rows="1" data-size="medium" data-show-faces="true" data-auto-logout-link="true"></div>

		<div id="form-div">
		
			<h1 align="center"> <font color = "#fff">Login</font></h1>
				<p align="center"><font color="#fff">Os campos com * s&atilde;o obrigat&oacute;rios</font></p>
			
			<p class="nome">
				<label for="emailCuidador">Login<span>*</span></label>
				<input name="loginCuidador" type="type"   required="required"   class="validate[required,custom[onlyLetter],length[0,100]] feedback-input"  id="loginCuidador" />
			</p>
		
			<p class="nome">
				<label for="senhaCuidador">Senha<span>*</span></label>
				<input name="senhaCuidador" type="password"   required="required"    class="validate[required,custom[onlyLetter],length[0,100]] feedback-input"  id="senhaCuidador" />
			</p>
		
			<div class="submit">
			<input type="submit" value="Entrar" id="button-blue"/>
			<div class="ease"></div>
		
		
			</div>
			</form>
		</div>
	</body>
</html>