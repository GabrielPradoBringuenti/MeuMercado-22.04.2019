<?php

error_reporting(0);


	include_once("./classes/Conexao.class.php");
	include_once("./classes/Produtos.class.php");
	
	$conn		  = new Conexao();
	$produto      = new Produtos($codigoProduto,$nomeProduto,$tipoProduto,$valorProduto,$estoqueProduto);

?>
<html>
	<head>
		<title>Cadastro de Produtos</title>	
		<script type="text/javascript" src ="js/somenteNumeros.js"></script> 
		<script src="//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
		<script src="//plentz.github.io/jquery-maskmoney/javascripts/jquery.maskMoney.min.js"></script>

	</head>
	   <body>
		 <fieldset>
			<table align="center">
				<form name="frmProdutos" action="cadastroProduto-p.php" method="Post">

					<legend align="center"> Cadastro de Produtos </legend>
			<!--	<tr>
					<td><label>Codigo Produto</label></td>
					<td><input type="codigoProduto" name="codigoProduto"  placeholder="Codigo Produto" required="required"></td>
				</tr> -->
				<tr>
					<td><label>Nome</label></td>
					<td><input type="nomeProduto" name="nomeProduto"  placeholder="Nome Produto" required="required"></td>
				</tr>
				<tr>
					<td><label>Tipo Produto</label></td>
					<td><input type="tipoProduto" name="tipoProduto"  placeholder="Tipo Produto" required="required"></td>
				</tr>
				<tr>
					<td><label>Valor Produto</label></td>
					<td><input type="text" id="meu-input" data-thousands="" data-decimal="," name="valorProduto"  placeholder="Valor Produto" required="required"></td>
						<script>
						$(function() {
						$('#meu-input').maskMoney();
						});
						</script>
				</tr>
				<tr>
					<td><label>Estoque Produto</label></td>
					<td><input type="text" name="estoqueProduto"  placeholder="Estoque Produto" required="required" onkeypress = "return somenteNumero(this)" ></td>
				</tr>
				<table align="center">
					<tr>
						<td colspan="2"> <input type="submit" name="cadastrar" value="Cadastrar"></td>
						<td><input type="reset" name="limpar" value="limpar"></td>
					<tr/>
					<tr>
						<a href="produto-c.php" > Consultar Produtos</a>
					 
					</tr>
				</table>
				</form>
			</table>
		  </fieldset>
	   </body>
</html>





