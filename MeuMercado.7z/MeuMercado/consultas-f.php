<html>
	<head>
		<title>Consultas</title>
	</head>
		<style type="text/css">
			.alinhar{
		 
				margin-right:25px;		 
		 
			}
		</style>	 
		<a href="consultaNome.php"> <img src="imagens/consultaProdutos.png" class="alinhar" width="120px"></a>
		<a href="consultaTipo.php"> <img src="imagens/buscaProdutos.png" class="alinhar" width="130px"></a>
</html>
