<?php
   
   error_reporting(0);
   
	if (isset($_GET['chave'])) {
		$chave = $_GET['chave']; // pega o valor passado por parametro
	}
	
    include_once("./classes/Conexao.class.php");
	include_once("./classes/Produtos.class.php");
	

	$conn 	          = new  Conexao();
	$produto          = new  Produtos($codigoProduto,$nomeProduto,$tipoProduto,$valorProduto,$estoqueProduto);
	
	if ($produto->localizarProduto($chave)) {
		// passa os dados do banco para o objeto

	
	 $codigoProduto             =  $produto->getCodigoProduto();
	 $nomeProduto               =  $produto->getNomeProduto();
     $tipoProduto               =  $produto->getTipoProduto();
	 $valorProduto              =  $produto->getValorProduto();
	 $estoqueProduto            =  $produto->getEstoqueProduto();
			
	 
	 
	}
	

	
?>

<html>
	<head>
		<meta charset="UTF-8">
		<title>Alteração de Produto</title>
		<script type="text/javascript" src ="js/somenteNumeros.js"></script> 
	</head>
	<body>
	<form name="formAlterar" action="cadastroProduto-p.php?acao=3&chave=<?php echo $chave?>" method="POST">
			<h1 align="center"><font color="#000">Alteração de Produto</font></h1>
			<div id="cadastrar"><a href="produto-c.php"  title="Voltar"> Voltar &raquo;</a></div>
			
		<div id="form-div">
		
			<p align="center"><font color="#fff">Os campos com * s&atilde;o obrigat&oacute;rios</font></p>
			
			
	 <p class="codigoProduto">
			<input name="codigoProduto" type="hidden"  required="required"    value="<?php echo $codigoProduto; ?>"      id="codigoLogradouro" />
      </p>
			
			
			
			
	  <p class="nomeProduto">
			<label for="nomeProduto">Nome<span>*</span></label>
			<input name="nomeProduto" type="text"  required="required"    value="<?php echo $nomeProduto; ?>"    id="nomeProduto" />
      </p>
	  
	  <p class="tipoProduto">
			<label for="tipoProduto">Tipo<span>*</span></label>
			<input name="tipoProduto" type="text"  required="required"    value="<?php echo $tipoProduto; ?>"    id="tipoProduto" />
      </p>
	  <p class="valorProduto">
			<label for="valorProduto">Valor<span>*</span></label>
			<input name="valorProduto" type="text"  required="required"    value="<?php echo $valorProduto; ?>"    id="nomeProduto" onkeypress = "return somenteNumero(this)" />
      </p>
	  <p class="EstoqueProduto">
			<label for="estoqueProduto">Estoque<span>*</span></label>
			<input name="estoqueProduto" type="text"  required="required"    value="<?php echo $estoqueProduto; ?>"    id="nomeProduto" onkeypress = "return somenteNumero(this)" />
      </p>
	  
	
	
	 
		<div class="submit">
        <input type="submit" value="Cadastrar" id="button-blue"/>
        <div class="ease"></div>
		
		
      </div>
	  </form>
  </div>
	</body>